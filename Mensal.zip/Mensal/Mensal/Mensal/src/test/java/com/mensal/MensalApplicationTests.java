package com.mensal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MensalApplicationTests {

	@Test
	void contextLoads() {
	}

}
