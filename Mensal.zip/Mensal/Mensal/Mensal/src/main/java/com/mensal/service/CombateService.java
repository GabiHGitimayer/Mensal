package com.mensal.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mensal.entity.Combate;
import com.mensal.entity.NPC;
import com.mensal.entity.Personagem;
import com.mensal.repository.CombateRep;
import com.mensal.repository.NPCRep;
import com.mensal.repository.PersonagemRep;

@Service
public class CombateService {

    @Autowired
    private CombateRep combateRepository;

    @Autowired
    private PersonagemRep personagemRepository;

    @Autowired
    private NPCRep npcRepository;

    @Transactional
    public Combate iniciarCombate(Long atacanteId, Long defensorId) {

        Personagem atacante = personagemRepository.findById(atacanteId)
                .orElseThrow(() -> new RuntimeException("Personagem atacante não encontrado"));


        NPC defensor = npcRepository.findById(defensorId)
                .orElseThrow(() -> new RuntimeException("NPC defensor não encontrado"));

        System.out.println("Iniciando combate entre: " + atacante.getNome() + " e " + defensor.getNome());
        System.out.println("Atacante - Ataque: " + atacante.getAtaque() + ", Vida: " + atacante.getVida());
        System.out.println("Defensor - Defesa: " + defensor.getDefesa() + ", Vida: " + defensor.getVida());


        Combate combate = new Combate();
        combate.setAtacante(atacante);
        combate.setDefensor(defensor);


        long dano = atacante.getAtaque() - defensor.getDefesa();
        System.out.println("Dano calculado: " + dano);

        if (dano > 0) {
            defensor.setVida(defensor.getVida() - dano);
            System.out.println("Defensor vida após dano: " + defensor.getVida());
        }


        String resultado = null;
        if (defensor.getVida() <= 0) {
            resultado = "Vitória";
            System.out.println("Resultado: Vitória do atacante");
        } else if (atacante.getVida() <= 0) {
            resultado = "Derrota";
            System.out.println("Resultado: Derrota do atacante");
        } else {
            resultado = "Combate em andamento";
            System.out.println("Resultado: Combate em andamento");
        }

        combate.setResultado(resultado);

        // Salva o combate e persiste as mudanças na vida do defensor
        npcRepository.save(defensor);  // Persistindo as alterações na vida do NPC
        combateRepository.save(combate);

        return combate;
    }

    public List<Combate> obterCombatesPorPersonagem(Personagem personagem) {
        return combateRepository.findByAtacante(personagem);
    }

    public List<Combate> obterCombatesPorNpc(NPC npc) {
        return combateRepository.findByDefensor(npc);
    }
}
