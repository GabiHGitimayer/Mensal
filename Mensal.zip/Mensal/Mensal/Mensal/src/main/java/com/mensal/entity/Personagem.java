package com.mensal.entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Table
@Entity(name = "personagem")
public class Personagem {

	@Id
	@GeneratedValue (strategy = GenerationType.IDENTITY)
	private Long id;
	private String nome;
	private String classe;
	private String raca;
	private String nivel;
	private Long vida;
	private Long ataque;
	private Long mana;

    @OneToMany(mappedBy = "atacante")
    @JsonIgnoreProperties("atacante")
    private List<Combate> combates;
    
    @ManyToMany
	@JoinTable( name = "personagem_habilidade", 
		joinColumns = @JoinColumn (name = "personagem_id"), 
		inverseJoinColumns = @JoinColumn (name = "habilidade_id")
	)
    private List<Habilidade> habilidades;
	
	@ManyToMany(mappedBy = "personagens")
	private List<Jogador> jogadores;
	
}
