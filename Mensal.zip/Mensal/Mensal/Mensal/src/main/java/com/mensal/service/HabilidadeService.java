package com.mensal.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.mensal.entity.Habilidade;
import com.mensal.repository.HabilidadeRep;

@Service
public class HabilidadeService {
    @Autowired
    private HabilidadeRep habilidadeRep;

    public Habilidade criarHabilidade(Habilidade habilidade) {
        return habilidadeRep.save(habilidade);
    }

    public Habilidade atualizarHabilidade(Long id, Habilidade habilidadeAtualizada) {
        Habilidade habilidade = habilidadeRep.findById(id)
            .orElseThrow();

        habilidade.setNome(habilidadeAtualizada.getNome());
        habilidade.setDano(habilidadeAtualizada.getDano());
        habilidade.setManaCusto(habilidadeAtualizada.getManaCusto());

        return habilidadeRep.save(habilidade);
    }

    public List<Habilidade> listarHabilidades() {
        return habilidadeRep.findAll();
    }

    public Habilidade buscarHabilidadePorId(Long id) {
        return habilidadeRep.findById(id)
            .orElseThrow();
    }

    public void deletarHabilidade(Long id) {
        Habilidade habilidade = habilidadeRep.findById(id)
            .orElseThrow();
        habilidadeRep.delete(habilidade);
    }
}
