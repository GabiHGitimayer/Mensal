package com.mensal.entity;

import java.util.List;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "jogador")
@Entity
public class Jogador {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nome;
    private String usuario;
    private String email;
    private String senha;
    private Long nivel;
    private Long exp;

    @ManyToMany
	@JoinTable( name = "jogador_personagem", 
		joinColumns = @JoinColumn (name = "jogador_id"), 
		inverseJoinColumns = @JoinColumn (name = "personagem_id")
)
    private List<Personagem> personagens;
}
