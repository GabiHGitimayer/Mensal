package com.mensal.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mensal.entity.Habilidade;

public interface HabilidadeRep extends JpaRepository<Habilidade, Long> {
    List<Habilidade> findByNome(String nome);
}