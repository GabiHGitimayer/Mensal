package com.mensal.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mensal.entity.Habilidade;
import com.mensal.service.HabilidadeService;

@RestController
@RequestMapping("/api/habilidades")
public class HabilidadeControl {
    @Autowired
    private HabilidadeService habilidadeService;

    @PostMapping("/{nome}/{dano}/{mana}")
    public ResponseEntity<Habilidade> criarHabilidade(@RequestBody Habilidade habilidade) {
        Habilidade novaHabilidade = habilidadeService.criarHabilidade(habilidade);
        return ResponseEntity.status(HttpStatus.CREATED).body(novaHabilidade);
    }

    @GetMapping("/buscar")
    public ResponseEntity<List<Habilidade>> listarHabilidades() {
        List<Habilidade> habilidades = habilidadeService.listarHabilidades();
        return ResponseEntity.ok(habilidades);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Habilidade> buscarHabilidadePorId(@PathVariable Long id) {
        Habilidade habilidade = habilidadeService.buscarHabilidadePorId(id);
        return ResponseEntity.ok(habilidade);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Habilidade> atualizarHabilidade(
        @PathVariable Long id,
        @RequestBody Habilidade habilidadeAtualizada
    ) {
        Habilidade habilidade = habilidadeService.atualizarHabilidade(id, habilidadeAtualizada);
        return ResponseEntity.ok(habilidade);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletarHabilidade(@PathVariable Long id) {
        habilidadeService.deletarHabilidade(id);
        return ResponseEntity.noContent().build();
    }
}
