package com.mensal.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mensal.entity.Personagem;
import com.mensal.repository.PersonagemRep;

@Service
public class PersonagemService {

	@Autowired
	private PersonagemRep personagemRep;
	
	public Personagem savePersonagem(Personagem personagem){
		return personagemRep.save(personagem);
	}
	
    public Personagem findById(Long id){
        try{
            return personagemRep.findById(id).orElseThrow(); // orElseThrow(); é oq lança a exceção se der null
        }catch (Exception e){
            System.out.println(e.getCause()); //getCause indica pq ocorreu a exceção
            return new Personagem();
        }
    }
	   
	public List<Personagem> findAll() {
		return personagemRep.findAll();
	}
	
    public Personagem atualizarPersonagem(Long id, Personagem personagemAtualizado) {
        Personagem personagem = personagemRep.findById(id)
            .orElseThrow();
        personagem.setNome(personagemAtualizado.getNome());
        personagem.setClasse(personagemAtualizado.getClasse());
        personagem.setRaca(personagemAtualizado.getRaca());
        personagem.setNivel(personagemAtualizado.getNivel());
        personagem.setVida(personagemAtualizado.getVida());
        personagem.setAtaque(personagemAtualizado.getAtaque());
        personagem.setMana(personagemAtualizado.getMana());
        
        

        return personagemRep.save(personagem);
    }
    
    public void deletarPersonagem(Long id) {
        Personagem personagem = personagemRep.findById(id)
            .orElseThrow();
        personagemRep.delete(personagem);
    }
	
	
}
